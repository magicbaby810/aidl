package com.sk.aidltestb;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.sk.aidltest.AidlTest;

public class MainActivity extends AppCompatActivity {

    private AidlTest aidlTest;

    private TextView btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        intent.setAction("ForServiceAidl");
        intent.setPackage("com.sk.aidltest");
        boolean isSuccess = bindService(intent, connection, Service.BIND_AUTO_CREATE);
        Log.e("isSuccess", "" + isSuccess);

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != aidlTest) {
                    try {
                        String name = aidlTest.getValue();
                        Toast.makeText(MainActivity.this, "远程调用成功：" + name, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "远程调用失败", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            aidlTest = AidlTest.Stub.asInterface(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };
}
