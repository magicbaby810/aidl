package com.sk.aidltest;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private AidlTest aidlTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent();
        intent.setAction("ForServiceAidl");
        intent.setPackage("com.sk.aidltest");
        bindService(intent, connection, Service.BIND_AUTO_CREATE);
        setContentView(R.layout.activity_main);
    }

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            aidlTest = AidlTest.Stub.asInterface(service);
            if (null != aidlTest) {
                try {
                    aidlTest.setValue("hello?");
                    Toast.makeText(MainActivity.this, "连接成功", Toast.LENGTH_SHORT);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "连接失败", Toast.LENGTH_SHORT);
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };
}
