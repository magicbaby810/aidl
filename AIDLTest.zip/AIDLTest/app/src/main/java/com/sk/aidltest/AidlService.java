package com.sk.aidltest;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;

/**
 * Created by ola_sk on 2018/11/21.
 * Email: magicbaby810@gmail.com
 */
public class AidlService extends Service {


    private AidlTest.Stub aidlTest = new AAA();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return aidlTest;
    }
}
