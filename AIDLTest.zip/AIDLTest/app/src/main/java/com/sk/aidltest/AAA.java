package com.sk.aidltest;

import android.os.RemoteException;

/**
 * Created by ola_sk on 2018/11/20.
 * Email: magicbaby810@gmail.com
 */
public class AAA extends AidlTest.Stub {

    private String value;

    @Override
    public void stop() {

    }

    @Override
    public void setValue(String value) throws RemoteException {
        this.value = value;
    }

    @Override
    public String getValue() throws RemoteException {
        return value;
    }
}
